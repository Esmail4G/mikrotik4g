import { File } from "expo-file-system";
import * as DocumentPicker from "expo-document-picker";
import { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";

import { analyzeCardSample, type CardPatternReport } from "@/features/patterns/card-pattern-engine";
import { probeInternet, type InternetProbeResult } from "@/features/connectivity/internet-probe";
import { HotspotBrowser, type PortalPageSignal } from "@/features/hotspot/HotspotBrowser";
import { ChapHelper } from "@/features/chap/ChapHelper";
import {
  GatewayAddressError,
  normalizeGatewayAddress,
  portalErrorLabel,
} from "@/features/hotspot/gateway";

const COLORS = {
  navy: "#0B2635",
  deep: "#071722",
  teal: "#087E8B",
  cyan: "#4CC9C0",
  ink: "#153545",
  muted: "#59717B",
  line: "#DCE7EB",
  canvas: "#F2F7F9",
  surface: "#FFFFFF",
  pale: "#E7F5F3",
  amber: "#A75E0B",
  amberBg: "#FFF4E4",
  red: "#B42318",
  redBg: "#FFF0EF",
  green: "#16735E",
};

const SYNTHETIC_SAMPLE = Array.from({ length: 15 }, (_, index) => `4242000${String(index + 1).padStart(3, "0")}`).join("\n");

type LoginState = "not_checked" | "login_page" | "page_hint" | "rejected";

export default function HomeScreen() {
  const [showSplash, setShowSplash] = useState(true);
  const [gatewayInput, setGatewayInput] = useState("a.com");
  const [activeGateway, setActiveGateway] = useState<ReturnType<typeof normalizeGatewayAddress> | null>(null);
  const [pendingHttpGateway, setPendingHttpGateway] = useState<ReturnType<typeof normalizeGatewayAddress> | null>(null);
  const [browserVisible, setBrowserVisible] = useState(false);
  const [gatewayError, setGatewayError] = useState("");
  const [loginState, setLoginState] = useState<LoginState>("not_checked");
  const [portalMessage, setPortalMessage] = useState("");
  const [pageSignal, setPageSignal] = useState<PortalPageSignal | null>(null);
  const [sampleText, setSampleText] = useState("");
  const [sampleName, setSampleName] = useState("");
  const [sampleError, setSampleError] = useState("");
  const [report, setReport] = useState<CardPatternReport | null>(null);
  const [prefix, setPrefix] = useState("");
  const [internetResult, setInternetResult] = useState<InternetProbeResult | null>(null);
  const [checkingInternet, setCheckingInternet] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  const loginLabel = useMemo(() => {
    switch (loginState) {
      case "login_page":
        return "لم يتم تسجيل الدخول — صفحة الدخول ظاهرة";
      case "page_hint":
        return "تم تسجيل الدخول بحسب مؤشر صفحة الراوتر — غير متحقق منه مستقلًا";
      case "rejected":
        return "رفضت صفحة الراوتر بيانات الدخول";
      default:
        return "لم يُتحقق من تسجيل الدخول";
    }
  }, [loginState]);

  const openGateway = () => {
    setGatewayError("");
    setPortalMessage("");
    try {
      const target = normalizeGatewayAddress(gatewayInput);
      beginBrowser(target);
    } catch (error) {
      if (error instanceof GatewayAddressError && error.code === "http_confirmation_required") {
        try {
          setPendingHttpGateway(normalizeGatewayAddress(gatewayInput, true));
        } catch (nestedError) {
          setGatewayError(nestedError instanceof Error ? nestedError.message : "عنوان البوابة غير صالح.");
        }
        return;
      }
      setGatewayError(error instanceof Error ? error.message : "تعذر فتح عنوان البوابة.");
    }
  };

  const beginBrowser = (target: ReturnType<typeof normalizeGatewayAddress>) => {
    setActiveGateway(target);
    setLoginState("not_checked");
    setPageSignal(null);
    setInternetResult(null);
    setBrowserVisible(true);
  };

  const importSample = async () => {
    setSampleError("");
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ["text/plain", "text/csv", "application/csv", "text/comma-separated-values"],
        copyToCacheDirectory: true,
        multiple: false,
      });
      if (result.canceled || !result.assets?.[0]) return;
      const asset = result.assets[0];
      const file = asset.file ?? new File(asset.uri);
      const byteSize = typeof asset.size === "number" ? asset.size : file.size;
      if (!Number.isFinite(byteSize)) {
        throw new Error("تعذر التحقق من حجم الملف؛ اختر ملفًا محليًا يظهر حجمه في مدير الملفات.");
      }
      if (byteSize > 2 * 1024 * 1024) {
        throw new Error("حجم العينة أكبر من 2 ميغابايت؛ اختر ملفًا أصغر.");
      }
      const content = await file.text();
      if (!content.trim()) throw new Error("الملف فارغ.");
      setSampleText(content);
      setSampleName(asset.name);
      setReport(null);
      setSampleError("");
    } catch (error) {
      setSampleError(error instanceof Error ? error.message : "تعذر قراءة الملف النصي.");
    }
  };

  const loadSyntheticSample = () => {
    setSampleText(SYNTHETIC_SAMPLE);
    setSampleName("بيانات اصطناعية للاختبار فقط");
    setPrefix("42");
    setReport(null);
    setSampleError("");
  };

  const runAnalysis = () => {
    setSampleError("");
    try {
      setReport(analyzeCardSample(sampleText, prefix));
    } catch (error) {
      setReport(null);
      setSampleError(error instanceof Error ? error.message : "تعذر تحليل العينة.");
    }
  };

  const runInternetCheck = async () => {
    setCheckingInternet(true);
    setInternetResult(null);
    try {
      setInternetResult(await probeInternet());
    } catch {
      setInternetResult({ status: "probe_error", message: "تعذر إتمام الفحص.", wifiBindingVerified: false });
    } finally {
      setCheckingInternet(false);
    }
  };

  const handlePageSignal = (signal: PortalPageSignal) => {
    setPageSignal(signal);
    if (signal.errorCategory) {
      setLoginState("rejected");
      setPortalMessage(portalErrorLabel(signal.errorCategory));
    } else if (signal.hasLogoutMarker) {
      setLoginState("page_hint");
      setPortalMessage("رُصدت علامة خروج/جلسة في الصفحة؛ هذه إشارة من البوابة وليست تحققًا مستقلًا من المصادقة.");
    } else if (signal.hasUsernameField || signal.hasPasswordField) {
      setLoginState("login_page");
      setPortalMessage("رُصد نموذج دخول. أدخل بيانات شبكة تملك تصريحًا باستخدامها داخل صفحة الراوتر فقط.");
    }
  };

  const internetLabel = (result: InternetProbeResult | null) => {
    if (!result) return "لم يُجرَ فحص الإنترنت بعد";
    if (result.status === "system_route_reachable") return "استجاب فحص HTTPS عبر مسار النظام — ليس ربطًا مؤكدًا بـWi‑Fi";
    if (result.status === "wifi_required") return "لم يُثبت وجود Wi‑Fi مناسب؛ لم يُعلن نجاح";
    if (result.status === "no_connection") return "لا يوجد اتصال Wi‑Fi نشط";
    if (result.status === "no_external_access") return "لم يثبت الوصول إلى الإنترنت الخارجي";
    return "تعذر إجراء اختبار موثوق";
  };

  const statusColor = internetResult?.status === "system_route_reachable" ? COLORS.green : COLORS.muted;

  if (showSplash) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.deep, alignItems: "center", justifyContent: "center", padding: 28 }}>
        <View style={{ width: 92, height: 92, borderRadius: 28, backgroundColor: "#103442", alignItems: "center", justifyContent: "center", marginBottom: 22, borderWidth: 1, borderColor: "#23606A" }}>
          <BrandMark size={68} />
        </View>
        <Text style={{ color: "#F4FBFD", fontSize: 29, fontWeight: "900", textAlign: "center", writingDirection: "rtl" }}>MikroTik 4G</Text>
        <Text style={{ color: "#AFD3D8", fontSize: 15, marginTop: 8, textAlign: "center", writingDirection: "rtl" }}>إسماعيل فورجي</Text>
        <View style={{ marginTop: 22, height: 3, width: 68, borderRadius: 3, backgroundColor: COLORS.cyan }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.canvas }}>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 10, paddingBottom: 34, gap: 14 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12, paddingTop: 7, paddingBottom: 4 }}>
          <View style={{ width: 48, height: 48, borderRadius: 16, backgroundColor: COLORS.navy, alignItems: "center", justifyContent: "center" }}>
            <BrandMark size={36} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: COLORS.navy, fontWeight: "900", fontSize: 22, textAlign: "right", writingDirection: "rtl" }}>MikroTik 4G</Text>
            <Text style={{ color: COLORS.muted, fontSize: 13, textAlign: "right", marginTop: 2, writingDirection: "rtl" }}>تشخيص مسؤول، ونتائج قابلة للتحقق</Text>
          </View>
          <View style={{ backgroundColor: COLORS.pale, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 7 }}>
            <Text style={{ color: COLORS.green, fontWeight: "700", fontSize: 11, writingDirection: "rtl" }}>محلي</Text>
          </View>
        </View>

        <View style={styles.statusCard}>
          <View style={styles.sectionHeading}>
            <View style={{ flex: 1 }}>
              <Text style={styles.eyebrow}>حالة البوابة</Text>
              <Text style={styles.statusTitle}>{loginLabel}</Text>
            </View>
            <View style={[styles.statusDot, { backgroundColor: loginState === "rejected" ? COLORS.red : loginState === "page_hint" ? COLORS.amber : COLORS.teal }]} />
          </View>
          <Text style={styles.statusBodyText}>{portalMessage || "لن يُسجل الدخول تلقائيًا. افتح صفحة بوابة تملك تصريحًا باستخدامها."}</Text>
          {pageSignal && (
            <View style={styles.signalRow}>
              <Text style={styles.statusSmallNote}>
                حقول مرصودة: {pageSignal.fields.length ? pageSignal.fields.join("، ") : "لا شيء"}
                {pageSignal.hasChapMarkers ? " · مؤشرات CHAP ظاهرة" : " · لم تُرصد مؤشرات CHAP"}
              </Text>
            </View>
          )}
          {gatewayError ? <Text style={styles.errorText}>{gatewayError}</Text> : null}
          <View style={styles.divider} />
          <Text style={styles.statusFieldLabel}>عنوان بوابة HotSpot</Text>
          <View style={styles.inputShell}>
            <TextInput
              value={gatewayInput}
              onChangeText={setGatewayInput}
              placeholder="a.com أو 192.168.88.1"
              placeholderTextColor="#8AA0A8"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              textAlign="left"
              accessibilityLabel="عنوان بوابة MikroTik"
              style={styles.input}
            />
            <Ionicons name="globe-outline" size={19} color={COLORS.teal} />
          </View>
          <Pressable accessibilityRole="button" onPress={openGateway} style={styles.primaryButton}>
            <Ionicons name="open-outline" size={18} color="#FFFFFF" />
            <Text style={styles.primaryButtonText}>فتح المتصفح الداخلي</Text>
          </Pressable>
        </View>

        <View style={styles.sectionCard}>
          <View style={styles.sectionHeading}>
            <View style={styles.sectionIcon}><Ionicons name="pulse-outline" size={19} color={COLORS.teal} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.sectionTitle}>فحص الوصول الخارجي</Text>
              <Text style={styles.smallNote}>منفصل عن نجاح تسجيل الدخول</Text>
            </View>
          </View>
          <View style={styles.internetResultBox}>
            {checkingInternet ? <ActivityIndicator color={COLORS.teal} /> : <View style={[styles.statusDot, { backgroundColor: internetResult?.status === "system_route_reachable" ? COLORS.green : internetResult?.status === "no_external_access" ? COLORS.red : COLORS.amber }]} />}
            <Text style={[styles.internetLabel, { color: statusColor }]}>{checkingInternet ? "جارٍ اختبار HTTPS…" : internetLabel(internetResult)}</Text>
          </View>
          {internetResult && <Text style={styles.smallNote}>{internetResult.message}</Text>}
          <Pressable accessibilityRole="button" disabled={checkingInternet} onPress={runInternetCheck} style={[styles.secondaryButton, checkingInternet && { opacity: 0.6 }]}>
            <Ionicons name="cloud-done-outline" size={18} color={COLORS.teal} />
            <Text style={styles.secondaryButtonText}>{checkingInternet ? "جارٍ الفحص" : "اختبار HTTPS الآن"}</Text>
          </Pressable>
          <Text style={styles.footnote}>يتطلب الفحص أن يبلّغ النظام عن Wi‑Fi. Expo لا يتيح ربط الطلب بـAndroid Network محدد أو استبعاد VPN على نحو مضمون؛ لذلك لا نعرض نتيجة نجاح مكافئة لاختبار Wi‑Fi مرتبط.</Text>
        </View>

        <ChapHelper />

        <View style={styles.sectionCard}>
          <View style={styles.sectionHeading}>
            <View style={styles.sectionIcon}><Ionicons name="analytics-outline" size={19} color={COLORS.teal} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.sectionTitle}>تحليل عينة البطاقات</Text>
              <Text style={styles.smallNote}>محلي على الجهاز — لا توليد ولا تجربة دخول</Text>
            </View>
          </View>
          <Text style={styles.fieldLabel}>البادئة المطلوبة (رقمان)</Text>
          <View style={styles.inputShell}>
            <TextInput
              value={prefix}
              onChangeText={setPrefix}
              placeholder="مثال: 42"
              placeholderTextColor="#8AA0A8"
              keyboardType="number-pad"
              maxLength={2}
              textAlign="left"
              accessibilityLabel="بادئة البطاقة من رقمين"
              style={[styles.input, { maxWidth: 100 }]}
            />
            <Ionicons name="keypad-outline" size={18} color={COLORS.teal} />
          </View>
          <View style={styles.buttonRow}>
            <Pressable accessibilityRole="button" onPress={importSample} style={[styles.secondaryButton, { flex: 1 }]}>
              <Ionicons name="document-attach-outline" size={18} color={COLORS.teal} />
              <Text style={styles.secondaryButtonText}>استيراد CSV / TXT</Text>
            </Pressable>
            <Pressable accessibilityRole="button" onPress={loadSyntheticSample} style={[styles.outlineButton, { flex: 1 }]}>
              <Text style={styles.outlineButtonText}>عينة اصطناعية</Text>
            </Pressable>
          </View>
          <Text style={styles.smallNote}>
            {sampleName ? `العينة: ${sampleName}` : "اختر ملفًا نصيًا مصرحًا باستخدامه."} لا تُرفع العينة ولا تُحفظ في الحساب.
          </Text>
          {sampleError ? <Text style={styles.errorText}>{sampleError}</Text> : null}
          <Pressable accessibilityRole="button" onPress={runAnalysis} disabled={!sampleText.trim()} style={[styles.primaryButton, !sampleText.trim() && { opacity: 0.45 }]}>
            <Ionicons name="search-outline" size={18} color="#FFFFFF" />
            <Text style={styles.primaryButtonText}>فحص وتحليل العينة</Text>
          </Pressable>
          {report && <AnalysisResults report={report} />}
        </View>

        <View style={styles.noticeCard}>
          <Ionicons name="shield-checkmark-outline" size={21} color={COLORS.teal} />
          <Text style={styles.noticeText}>استخدم بيانات الشبكات والبطاقات التي لديك تصريح بها فقط. لا يُجري التطبيق تخمينًا متتابعًا ولا يسجل الدخول آليًا.</Text>
        </View>
        <Text style={styles.footer}>إسماعيل فورجي · معاينة Expo لا تثبت سلوك جهاز Android أو راوتر حقيقي.</Text>
      </ScrollView>

      <HotspotBrowser
        visible={browserVisible && !!activeGateway}
        url={activeGateway?.url ?? "https://example.invalid"}
        origin={activeGateway?.origin ?? "https://example.invalid"}
        secure={activeGateway?.secure ?? true}
        onClose={() => setBrowserVisible(false)}
        onSignal={handlePageSignal}
        onBrowserError={setGatewayError}
      />

      <Modal transparent visible={!!pendingHttpGateway} animationType="fade" onRequestClose={() => setPendingHttpGateway(null)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.confirmCard}>
            <Text style={styles.confirmTitle}>بوابة غير مشفرة</Text>
            <Text style={styles.bodyText}>الرابط يستخدم HTTP، وقد تتمكن أجهزة الشبكة من قراءة بيانات الدخول. تابع فقط إذا كنت تملك البوابة وتقبل هذا الخطر. لن يتم تعطيل تحقق TLS لأن هذا الرابط لا يستخدم HTTPS.</Text>
            <Text style={styles.httpUrl}>{pendingHttpGateway?.url}</Text>
            <Pressable accessibilityRole="button" onPress={() => {
              if (pendingHttpGateway) beginBrowser(pendingHttpGateway);
              setPendingHttpGateway(null);
            }} style={styles.dangerButton}>
              <Text style={styles.primaryButtonText}>أفهم الخطر — افتح HTTP</Text>
            </Pressable>
            <Pressable accessibilityRole="button" onPress={() => setPendingHttpGateway(null)} style={styles.cancelButton}>
              <Text style={styles.cancelButtonText}>إلغاء</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function AnalysisResults({ report }: { report: CardPatternReport }) {
  return (
    <View style={styles.resultsBox}>
      <Text style={styles.resultsTitle}>نتيجة العينة</Text>
      <Metric label="بطاقات صالحة وفريدة" value={String(report.uniqueValidCards)} />
      <Metric label={`تطابق البادئة ${report.prefix}`} value={String(report.matchingCards)} />
      <Metric label="الاحتمالات النظرية للأطوال المرصودة" value={report.theoreticalPossibilities} />
      <Metric label="المكرر / المستبعد" value={`${report.duplicateCards} / ${report.ignoredCells}`} />
      <Text style={styles.resultsSubhead}>الأطوال المرصودة</Text>
      {report.lengths.length ? report.lengths.map((item) => (
        <Metric key={item.length} label={`${item.length} أرقام`} value={`${item.count} مشاهد`} />
      )) : <Text style={styles.smallNote}>لا توجد بطاقة في العينة بهذه البادئة.</Text>}
      <Text style={styles.resultsSubhead}>اختبار حجز عينة لطول البطاقة فقط</Text>
      <Text style={styles.confidenceText}>
        {report.lengthHoldout
          ? `${report.lengthHoldout.accuracyPercent}% (${report.lengthHoldout.correct}/${report.lengthHoldout.tested} حالة)`
          : "غير محسوب: يلزم 10 بطاقات فريدة مطابقة على الأقل."}
      </Text>
      <Text style={styles.smallNote}>هذه الدقة لا تخص تخمين الرقم ولا نجاح الدخول.</Text>
      <Text style={styles.resultsSubhead}>تكرار الأرقام حسب الموقع — البطاقات المطابقة للبادئة {report.prefix}</Text>
      <View style={{ gap: 5 }}>
        {report.digitFrequencyByPosition.slice(0, 12).map((position) => (
          <Text key={position.position} style={styles.positionLine}>
            الموضع {position.position}: {position.counts.map((item) => `${item.digit}×${item.count}`).join("  ")}
          </Text>
        ))}
      </View>
      <Text style={styles.resultsSubhead}>التسلسلات المتجاورة</Text>
      <Text style={styles.bodyText}>
        {report.consecutiveRuns.length
          ? report.consecutiveRuns.map((run) => `${run.length} متتابعة (${run.first} … ${run.last})`).join("، ")
          : "لم يُرصد تسلسل متجاور بطول بطاقتين أو أكثر."}
      </Text>
      <Text style={styles.caveat}>{report.caveat}</Text>
    </View>
  );
}

function BrandMark({ size }: { size: number }) {
  return <Image source={require("../../assets/images/splash-icon.png")} resizeMode="contain" style={{ width: size, height: size }} accessibilityLabel="شعار شبكة داخل درع" />;
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metricRow}>
      <Text style={styles.metricValue} numberOfLines={2}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

const styles = {
  statusCard: { backgroundColor: COLORS.navy, borderRadius: 22, padding: 18, gap: 12 } as const,
  sectionCard: { backgroundColor: COLORS.surface, borderRadius: 22, padding: 17, borderWidth: 1, borderColor: COLORS.line, gap: 12 } as const,
  sectionHeading: { flexDirection: "row-reverse", alignItems: "center", gap: 12 } as const,
  eyebrow: { color: "#A9D6D8", fontSize: 11, fontWeight: "700", textAlign: "right", writingDirection: "rtl" } as const,
  statusTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "800", textAlign: "right", marginTop: 4, writingDirection: "rtl" } as const,
  statusBodyText: { color: "#E6F1F4", fontSize: 14, lineHeight: 22, textAlign: "right", writingDirection: "rtl" } as const,
  statusSmallNote: { color: "#C5DADF", fontSize: 12, lineHeight: 18, textAlign: "right", writingDirection: "rtl" } as const,
  statusFieldLabel: { color: "#E6F1F4", fontSize: 13, fontWeight: "700", textAlign: "right", writingDirection: "rtl" } as const,
  bodyText: { color: COLORS.ink, fontSize: 14, lineHeight: 22, textAlign: "right", writingDirection: "rtl" } as const,
  smallNote: { color: COLORS.muted, fontSize: 12, lineHeight: 18, textAlign: "right", writingDirection: "rtl" } as const,
  signalRow: { backgroundColor: "#123746", borderRadius: 12, padding: 10 } as const,
  statusDot: { width: 10, height: 10, borderRadius: 5 } as const,
  divider: { height: 1, backgroundColor: "#244452", marginVertical: 3 } as const,
  fieldLabel: { color: COLORS.ink, fontSize: 13, fontWeight: "700", textAlign: "right", writingDirection: "rtl" } as const,
  inputShell: { minHeight: 50, borderRadius: 14, borderWidth: 1, borderColor: COLORS.line, backgroundColor: "#FFFFFF", paddingHorizontal: 12, flexDirection: "row-reverse", alignItems: "center", gap: 10 } as const,
  input: { flex: 1, minHeight: 48, color: COLORS.ink, fontSize: 15, paddingVertical: 8, writingDirection: "ltr" } as const,
  primaryButton: { minHeight: 50, backgroundColor: COLORS.teal, borderRadius: 15, flexDirection: "row-reverse", gap: 8, alignItems: "center", justifyContent: "center", paddingHorizontal: 14, paddingVertical: 12 } as const,
  primaryButtonText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800", textAlign: "center", writingDirection: "rtl" } as const,
  secondaryButton: { minHeight: 46, borderRadius: 14, borderWidth: 1, borderColor: "#B8DCDD", backgroundColor: "#F1FAF9", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 10, paddingVertical: 10 } as const,
  secondaryButtonText: { color: COLORS.teal, fontSize: 13, fontWeight: "700", textAlign: "center", writingDirection: "rtl" } as const,
  outlineButton: { minHeight: 46, borderRadius: 14, borderWidth: 1, borderColor: COLORS.line, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", paddingHorizontal: 8, paddingVertical: 9 } as const,
  outlineButtonText: { color: COLORS.ink, fontSize: 13, fontWeight: "700", textAlign: "center", writingDirection: "rtl" } as const,
  sectionIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.pale, alignItems: "center", justifyContent: "center" } as const,
  sectionTitle: { color: COLORS.navy, fontSize: 17, fontWeight: "800", textAlign: "right", writingDirection: "rtl" } as const,
  internetResultBox: { minHeight: 46, borderRadius: 13, backgroundColor: COLORS.canvas, paddingHorizontal: 12, paddingVertical: 9, flexDirection: "row-reverse", alignItems: "center", gap: 9 } as const,
  internetLabel: { flex: 1, fontSize: 13, lineHeight: 19, fontWeight: "700", textAlign: "right", writingDirection: "rtl" } as const,
  footnote: { color: COLORS.muted, fontSize: 11, lineHeight: 17, textAlign: "right", writingDirection: "rtl" } as const,
  buttonRow: { flexDirection: "row-reverse", gap: 8 } as const,
  errorText: { color: COLORS.red, backgroundColor: COLORS.redBg, borderRadius: 10, padding: 10, fontSize: 12, lineHeight: 18, textAlign: "right", writingDirection: "rtl" } as const,
  resultsBox: { padding: 13, backgroundColor: "#F6FAFB", borderRadius: 15, borderWidth: 1, borderColor: COLORS.line, gap: 8 } as const,
  resultsTitle: { color: COLORS.navy, fontSize: 16, fontWeight: "900", textAlign: "right", writingDirection: "rtl" } as const,
  metricRow: { minHeight: 31, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 12, borderBottomWidth: 1, borderBottomColor: "#E5EEF0", paddingVertical: 5 } as const,
  metricLabel: { flex: 1, color: COLORS.muted, fontSize: 12, textAlign: "right", writingDirection: "rtl" } as const,
  metricValue: { maxWidth: "55%", color: COLORS.navy, fontSize: 13, fontWeight: "800", textAlign: "left", writingDirection: "ltr" } as const,
  resultsSubhead: { color: COLORS.teal, fontSize: 13, fontWeight: "800", textAlign: "right", marginTop: 5, writingDirection: "rtl" } as const,
  confidenceText: { color: COLORS.navy, fontSize: 19, fontWeight: "900", textAlign: "right", writingDirection: "ltr" } as const,
  positionLine: { color: COLORS.ink, fontSize: 12, textAlign: "right", writingDirection: "rtl" } as const,
  caveat: { color: COLORS.amber, backgroundColor: COLORS.amberBg, fontSize: 11, lineHeight: 17, textAlign: "right", writingDirection: "rtl", borderRadius: 10, padding: 9 } as const,
  noticeCard: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 10, backgroundColor: "#E9F4F2", borderRadius: 17, padding: 14, borderWidth: 1, borderColor: "#C5E2DE" } as const,
  noticeText: { flex: 1, color: COLORS.ink, fontSize: 12, lineHeight: 19, textAlign: "right", writingDirection: "rtl" } as const,
  footer: { color: COLORS.muted, fontSize: 11, textAlign: "center", writingDirection: "rtl", paddingTop: 2 } as const,
  modalBackdrop: { flex: 1, backgroundColor: "rgba(4,18,27,0.58)", alignItems: "center", justifyContent: "center", padding: 22 } as const,
  confirmCard: { width: "100%", maxWidth: 440, backgroundColor: COLORS.surface, borderRadius: 22, padding: 19, gap: 13 } as const,
  confirmTitle: { color: COLORS.amber, fontSize: 20, fontWeight: "900", textAlign: "right", writingDirection: "rtl" } as const,
  httpUrl: { color: COLORS.ink, fontSize: 12, textAlign: "left", writingDirection: "ltr" } as const,
  dangerButton: { minHeight: 48, borderRadius: 14, backgroundColor: COLORS.amber, alignItems: "center", justifyContent: "center", padding: 12 } as const,
  cancelButton: { minHeight: 44, borderRadius: 13, backgroundColor: COLORS.canvas, alignItems: "center", justifyContent: "center", padding: 11 } as const,
  cancelButtonText: { color: COLORS.ink, fontWeight: "700", writingDirection: "rtl" } as const,
};
