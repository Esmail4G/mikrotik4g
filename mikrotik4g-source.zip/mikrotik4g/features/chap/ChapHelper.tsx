import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import { computeChapResponse } from "@/features/chap/chap";

const colors = { navy: "#0B2635", teal: "#087E8B", muted: "#59717B", border: "#DCE7EB", pale: "#F2F7F9", amber: "#A75E0B" };
const fieldStyle = { minHeight: 46, borderWidth: 1, borderColor: colors.border, borderRadius: 13, paddingHorizontal: 12, color: colors.navy, fontSize: 14, textAlign: "left" as const, writingDirection: "ltr" as const };

export function ChapHelper() {
  const [chapId, setChapId] = useState("");
  const [challenge, setChallenge] = useState("");
  const [password, setPassword] = useState("");
  const [response, setResponse] = useState("");
  const [error, setError] = useState("");

  const calculate = () => {
    setError("");
    setResponse("");
    try {
      const result = computeChapResponse({ chapId, password, challengeHex: challenge });
      setResponse(result);
      setPassword("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "تعذر حساب استجابة CHAP.");
      setPassword("");
    }
  };

  return (
    <View style={{ backgroundColor: "#FFFFFF", borderRadius: 22, padding: 17, borderWidth: 1, borderColor: colors.border, gap: 11 }}>
      <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
        <View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: "#E7F5F3", alignItems: "center", justifyContent: "center" }}>
          <Ionicons name="key-outline" size={19} color={colors.teal} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.navy, fontSize: 17, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }}>مساعد CHAP</Text>
          <Text style={{ color: colors.muted, fontSize: 12, textAlign: "right", marginTop: 2, writingDirection: "rtl" }}>أداة يدوية مستقلة — لا ترسل بيانات إلى الراوتر</Text>
        </View>
      </View>
      <Text style={{ color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "right", writingDirection: "rtl" }}>
        احسب `MD5(chap-id byte || كلمة المرور UTF‑8 || chap-challenge bytes)` لبوابة تملك تصريحًا باستخدامها. لا تُحقن النتيجة في صفحة الويب تلقائيًا.
      </Text>
      <TextInput value={chapId} onChangeText={setChapId} placeholder="chap-id (مثل 7 أو 0x07)" placeholderTextColor="#8AA0A8" autoCapitalize="none" style={fieldStyle} accessibilityLabel="قيمة chap-id" />
      <TextInput value={challenge} onChangeText={setChallenge} placeholder="chap-challenge سداسي عشري" placeholderTextColor="#8AA0A8" autoCapitalize="none" style={fieldStyle} accessibilityLabel="قيمة chap-challenge" />
      <TextInput value={password} onChangeText={setPassword} placeholder="كلمة المرور — تُمسح بعد الحساب" placeholderTextColor="#8AA0A8" secureTextEntry autoCapitalize="none" style={fieldStyle} accessibilityLabel="كلمة مرور CHAP" />
      {error ? <Text style={{ color: "#B42318", fontSize: 12, textAlign: "right", writingDirection: "rtl" }}>{error}</Text> : null}
      {response ? (
        <View style={{ backgroundColor: colors.pale, borderRadius: 12, padding: 12, gap: 5 }}>
          <Text style={{ color: colors.teal, fontSize: 12, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }}>استجابة CHAP (حددها وانسخها يدويًا إن لزم)</Text>
          <Text selectable style={{ color: colors.navy, fontSize: 14, fontWeight: "800", textAlign: "left", writingDirection: "ltr" }}>{response}</Text>
          <Text style={{ color: colors.muted, fontSize: 11, textAlign: "right", writingDirection: "rtl" }}>لا تستخدم MD5 لتخزين كلمات المرور؛ هنا لحساب قيمة البروتوكول فقط.</Text>
        </View>
      ) : null}
      <Pressable accessibilityRole="button" onPress={calculate} style={{ minHeight: 47, backgroundColor: colors.teal, borderRadius: 14, alignItems: "center", justifyContent: "center", padding: 11 }}>
        <Text style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "800", writingDirection: "rtl" }}>حساب استجابة CHAP</Text>
      </Pressable>
      <Text style={{ color: colors.amber, fontSize: 11, lineHeight: 17, textAlign: "right", writingDirection: "rtl" }}>
        كلمة المرور تبقى مؤقتًا في ذاكرة الشاشة فقط وتُمسح من الحقل بعد الحساب؛ لا يسجلها التطبيق. صفحة MikroTik الأصلية قد تحسب CHAP بنفسها عند تسجيل الدخول.
      </Text>
    </View>
  );
}
