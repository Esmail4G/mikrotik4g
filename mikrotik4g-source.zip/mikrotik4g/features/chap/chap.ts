export type ChapInput = {
  chapId: string | number;
  password: string;
  challengeHex: string;
};

/** CHAP uses MD5(identifier byte || UTF-8 password bytes || challenge bytes). */
export function computeChapResponse({ chapId, password, challengeHex }: ChapInput): string {
  if (password.length > 4096) throw new Error("كلمة المرور أطول من الحد المسموح.");
  const identifier = parseChapIdentifier(chapId);
  const challenge = parseHexBytes(challengeHex);
  if (challenge.length === 0 || challenge.length > 1024) throw new Error("تحدي CHAP غير صالح.");
  const secret = encodeUtf8(password);
  const input = new Uint8Array(1 + secret.length + challenge.length);
  input[0] = identifier;
  input.set(secret, 1);
  input.set(challenge, 1 + secret.length);
  return bytesToHex(md5(input));
}

export function parseChapIdentifier(value: string | number): number {
  if (typeof value === "number") {
    if (!Number.isInteger(value) || value < 0 || value > 255) throw new Error("chap-id يجب أن يكون بايتًا بين 0 و255.");
    return value;
  }
  const normalized = value.trim();
  let parsed: number;
  if (/^0x[0-9a-f]{1,2}$/i.test(normalized)) {
    parsed = Number.parseInt(normalized.slice(2), 16);
  } else if (/^[0-9a-f]{2}$/i.test(normalized) && /[a-f]/i.test(normalized)) {
    parsed = Number.parseInt(normalized, 16);
  } else if (/^\d{1,3}$/.test(normalized)) {
    parsed = Number.parseInt(normalized, 10);
  } else {
    throw new Error("صيغة chap-id غير صالحة؛ استخدم رقمًا عشريًا أو 0xHH.");
  }
  if (parsed < 0 || parsed > 255) throw new Error("chap-id يجب أن يكون بايتًا بين 0 و255.");
  return parsed;
}

export function parseHexBytes(input: string): Uint8Array {
  const value = input.trim().replace(/^(?:0x|hex:)/i, "").replace(/[\s:.-]/g, "");
  if (!value || value.length % 2 !== 0 || !/^[0-9a-f]+$/i.test(value)) {
    throw new Error("chap-challenge يجب أن يكون سلسلة بايتات سداسية عشرية كاملة.");
  }
  const bytes = new Uint8Array(value.length / 2);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Number.parseInt(value.slice(index * 2, index * 2 + 2), 16);
  }
  return bytes;
}

export function md5HexUtf8(value: string): string {
  return bytesToHex(md5(encodeUtf8(value)));
}

function encodeUtf8(value: string): Uint8Array {
  const bytes: number[] = [];
  for (let index = 0; index < value.length; index += 1) {
    let codePoint = value.charCodeAt(index);
    if (codePoint >= 0xd800 && codePoint <= 0xdbff && index + 1 < value.length) {
      const low = value.charCodeAt(index + 1);
      if (low >= 0xdc00 && low <= 0xdfff) {
        codePoint = 0x10000 + ((codePoint - 0xd800) << 10) + (low - 0xdc00);
        index += 1;
      }
    }
    if (codePoint <= 0x7f) bytes.push(codePoint);
    else if (codePoint <= 0x7ff) {
      bytes.push(0xc0 | (codePoint >> 6), 0x80 | (codePoint & 0x3f));
    } else if (codePoint <= 0xffff) {
      bytes.push(0xe0 | (codePoint >> 12), 0x80 | ((codePoint >> 6) & 0x3f), 0x80 | (codePoint & 0x3f));
    } else {
      bytes.push(0xf0 | (codePoint >> 18), 0x80 | ((codePoint >> 12) & 0x3f), 0x80 | ((codePoint >> 6) & 0x3f), 0x80 | (codePoint & 0x3f));
    }
  }
  return Uint8Array.from(bytes);
}

function md5(input: Uint8Array): Uint8Array {
  const paddedLength = Math.ceil((input.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(input);
  padded[input.length] = 0x80;
  const bitLengthLow = (input.length * 8) >>> 0;
  const bitLengthHigh = Math.floor((input.length * 8) / 0x1_0000_0000) >>> 0;
  for (let byte = 0; byte < 4; byte += 1) {
    padded[paddedLength - 8 + byte] = (bitLengthLow >>> (byte * 8)) & 0xff;
    padded[paddedLength - 4 + byte] = (bitLengthHigh >>> (byte * 8)) & 0xff;
  }

  const shifts = [
    7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
    5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
    4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
    6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
  ];
  const constants = Array.from({ length: 64 }, (_, index) => Math.floor(Math.abs(Math.sin(index + 1)) * 0x1_0000_0000) >>> 0);
  let a0 = 0x67452301;
  let b0 = 0xefcdab89;
  let c0 = 0x98badcfe;
  let d0 = 0x10325476;

  for (let offset = 0; offset < padded.length; offset += 64) {
    const words = new Uint32Array(16);
    for (let word = 0; word < 16; word += 1) {
      const start = offset + word * 4;
      words[word] = (padded[start] ?? 0) | ((padded[start + 1] ?? 0) << 8) | ((padded[start + 2] ?? 0) << 16) | ((padded[start + 3] ?? 0) << 24);
    }
    let a = a0;
    let b = b0;
    let c = c0;
    let d = d0;

    for (let index = 0; index < 64; index += 1) {
      let f: number;
      let wordIndex: number;
      if (index < 16) {
        f = (b & c) | (~b & d);
        wordIndex = index;
      } else if (index < 32) {
        f = (d & b) | (~d & c);
        wordIndex = (5 * index + 1) % 16;
      } else if (index < 48) {
        f = b ^ c ^ d;
        wordIndex = (3 * index + 5) % 16;
      } else {
        f = c ^ (b | ~d);
        wordIndex = (7 * index) % 16;
      }
      const oldD = d;
      d = c;
      c = b;
      const sum = (a + f + constants[index]! + words[wordIndex]!) | 0;
      b = (b + rotateLeft(sum, shifts[index]!)) | 0;
      a = oldD;
    }

    a0 = (a0 + a) >>> 0;
    b0 = (b0 + b) >>> 0;
    c0 = (c0 + c) >>> 0;
    d0 = (d0 + d) >>> 0;
  }

  const digest = new Uint8Array(16);
  [a0, b0, c0, d0].forEach((word, wordIndex) => {
    for (let byte = 0; byte < 4; byte += 1) digest[wordIndex * 4 + byte] = (word >>> (byte * 8)) & 0xff;
  });
  return digest;
}

function rotateLeft(value: number, count: number): number {
  return (value << count) | (value >>> (32 - count));
}

function bytesToHex(bytes: Uint8Array): string {
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
