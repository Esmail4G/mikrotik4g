import type { NetworkState } from "expo-network";

export const CONNECTIVITY_CHECK_URL = "https://connectivitycheck.gstatic.com/generate_204";
export const NETWORK_BINDING_NOTE =
  "هذا اختبار عبر مسار اتصال النظام؛ لا يثبت Expo أنه مربوط بشبكة Wi‑Fi المختارة ولا يستبعد VPN بصورة مضمونة.";

export type InternetProbeResult =
  | { status: "wifi_required"; message: string; wifiBindingVerified: false }
  | { status: "no_connection"; message: string; wifiBindingVerified: false }
  | { status: "system_route_reachable"; message: string; wifiBindingVerified: false; httpStatus: number }
  | { status: "no_external_access"; message: string; wifiBindingVerified: false; httpStatus?: number }
  | { status: "probe_error"; message: string; wifiBindingVerified: false };

export type ProbeDependencies = {
  getNetworkState: () => Promise<NetworkState>;
  fetcher: (url: string, init: RequestInit) => Promise<{ status: number }>;
  timeoutMs?: number;
};

const defaultDependencies: ProbeDependencies = {
  getNetworkState: async () => {
    const network = await import("expo-network");
    return network.getNetworkStateAsync();
  },
  fetcher: (url, init) => fetch(url, init),
  timeoutMs: 7000,
};

export async function probeInternet(dependencies: ProbeDependencies = defaultDependencies): Promise<InternetProbeResult> {
  let network: NetworkState;
  try {
    network = await dependencies.getNetworkState();
  } catch {
    return { status: "probe_error", message: "تعذر قراءة حالة الشبكة من النظام.", wifiBindingVerified: false };
  }

  if (network.type !== "WIFI") {
    return {
      status: "wifi_required",
      message: network.type === "VPN"
        ? "يظهر اتصال VPN نشطًا؛ لن تُعرض نتيجة إنترنت ناجحة."
        : "يتطلب هذا الفحص أن يبلّغ النظام عن Wi‑Fi؛ لم يُجرَ اختبار HTTPS.",
      wifiBindingVerified: false,
    };
  }
  if (network.isConnected === false) {
    return { status: "no_connection", message: "لا يوجد اتصال Wi‑Fi نشط وفق النظام.", wifiBindingVerified: false };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), dependencies.timeoutMs ?? 7000);
  try {
    const response = await dependencies.fetcher(CONNECTIVITY_CHECK_URL, {
      method: "GET",
      cache: "no-store",
      signal: controller.signal,
      headers: { Accept: "*/*" },
    });
    if (response.status === 204) {
      return {
        status: "system_route_reachable",
        message: `أعاد اختبار HTTPS استجابة 204 عبر مسار النظام. ${NETWORK_BINDING_NOTE}`,
        wifiBindingVerified: false,
        httpStatus: response.status,
      };
    }
    return {
      status: "no_external_access",
      message: `لم تُثبت نقطة الاختبار وصولًا خارجيًا (HTTP ${response.status}). قد تكون هناك بوابة أسيرة أو صفحة تحويل.`,
      wifiBindingVerified: false,
      httpStatus: response.status,
    };
  } catch {
    return {
      status: "no_external_access",
      message: "فشل اختبار HTTPS الخارجي أو انتهت مهلته؛ لم يُسجل نجاح للإنترنت.",
      wifiBindingVerified: false,
    };
  } finally {
    clearTimeout(timeout);
  }
}
