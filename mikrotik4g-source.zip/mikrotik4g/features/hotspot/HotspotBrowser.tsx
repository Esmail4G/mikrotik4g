import { useMemo } from "react";
import { Linking, Modal, Platform, Pressable, Text, View } from "react-native";
import { WebView } from "react-native-webview";

import { isAllowedGatewayNavigation, type PortalErrorCategory } from "@/features/hotspot/gateway";

export type PortalPageSignal = {
  origin: string;
  fields: string[];
  hasUsernameField: boolean;
  hasPasswordField: boolean;
  hasChapMarkers: boolean;
  hasLogoutMarker: boolean;
  errorCategory: PortalErrorCategory | null;
};

type Props = {
  visible: boolean;
  url: string;
  origin: string;
  secure: boolean;
  onClose: () => void;
  onSignal: (signal: PortalPageSignal) => void;
  onBrowserError: (message: string) => void;
};

const PAGE_SCAN_SCRIPT = `(function(){
  try {
    var fields = Array.from(document.querySelectorAll('input[name]'))
      .map(function(el){ return String(el.name || '').toLowerCase().replace(/[^a-z0-9_-]/g,'').slice(0,40); })
      .filter(Boolean).slice(0,16);
    var hasUsername = Array.from(document.querySelectorAll('input[name]')).some(function(el){ return /user(name)?/i.test(el.name || ''); });
    var hasPassword = Array.from(document.querySelectorAll('input[type="password"],input[name]')).some(function(el){ return String(el.type || '').toLowerCase() === 'password' || /pass(word)?/i.test(el.name || ''); });
    var markup = String(document.documentElement ? document.documentElement.innerHTML : '').toLowerCase();
    var chap = markup.indexOf('chap-id') !== -1 || markup.indexOf('chap-challenge') !== -1;
    var hasLogout = Array.from(document.querySelectorAll('a,button,input[type="submit"]')).some(function(el){
      var words = String(el.innerText || el.value || el.getAttribute('href') || '').toLowerCase();
      return /logout|log-out|sign out|تسجيل الخروج|خروج/.test(words);
    });
    var errorNodes = Array.from(document.querySelectorAll('.error,#error,.alert,.message,.status,[role="alert"]'))
      .filter(function(el){ return el && el.offsetParent !== null; })
      .map(function(el){ return String(el.innerText || '').slice(0,240); }).join(' ');
    var text = errorNodes.toLowerCase();
    var error = null;
    if (/expired|انتهت\\s*(الصلاحية|صلاحية)|منتهي\\s*الصلاحية/.test(text)) error = 'expired_code';
    else if (/limit|too many|simultaneous|concurrent|الحد\\s*الأقصى|عدد\\s*الجلسات/.test(text)) error = 'session_limit';
    else if (/radius|server\\s*(unavailable|timeout)|service\\s*unavailable|خادم\\s*غير\\s*متاح/.test(text)) error = 'service_unavailable';
    else if (/invalid|incorrect|wrong|unauthori[sz]ed|failed|denied|غير\\s*صحيح|مرفوض|خطأ/.test(text)) error = 'invalid_credentials';
    else if (text) error = 'other_error';
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
      v: 1, origin: location.origin, fields: fields, hasUsernameField: hasUsername,
      hasPasswordField: hasPassword, hasChapMarkers: chap, hasLogoutMarker: hasLogout, errorCategory: error
    }));
  } catch (_) {}
  true;
})();`;

export function HotspotBrowser({ visible, url, origin, secure, onClose, onSignal, onBrowserError }: Props) {
  const originWhitelist = useMemo(() => [origin], [origin]);

  const openExternal = async () => {
    try {
      await Linking.openURL(url);
    } catch {
      onBrowserError("تعذر فتح الرابط في متصفح النظام.");
    }
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} presentationStyle="fullScreen">
      <View style={{ flex: 1, backgroundColor: "#071722" }}>
        <View style={{ minHeight: 68, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 10, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: "#F5FBFF", fontSize: 15, fontWeight: "700", textAlign: "right" }}>متصفح البوابة</Text>
            <Text numberOfLines={1} style={{ color: secure ? "#5DD5C4" : "#FFC36A", fontSize: 12, textAlign: "right", marginTop: 3 }}>
              {secure ? "اتصال HTTPS" : "HTTP غير مشفر — استخدمه على شبكة موثوقة فقط"} · {new URL(url).hostname}
            </Text>
          </View>
          <Pressable accessibilityRole="button" accessibilityLabel="إغلاق المتصفح" onPress={onClose} style={{ padding: 12, borderRadius: 14, backgroundColor: "#163342" }}>
            <Text style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "700" }}>إغلاق</Text>
          </Pressable>
        </View>
        {!secure && (
          <View style={{ paddingHorizontal: 16, paddingVertical: 9, backgroundColor: "#50351A" }}>
            <Text style={{ color: "#FFE4B5", textAlign: "right", fontSize: 12, lineHeight: 18 }}>
              HTTP لا يشفر بيانات الدخول. لا تدخل كلمة مرور هنا إلا إذا كنت تملك البوابة وتقبل هذا الخطر.
            </Text>
          </View>
        )}
        {Platform.OS === "web" ? (
          <View style={{ flex: 1, padding: 22, justifyContent: "center", gap: 12, backgroundColor: "#F2F7F9" }}>
            <Text style={{ fontSize: 20, fontWeight: "800", textAlign: "right", color: "#0B2635" }}>معاينة المتصفح على الويب غير أصلية</Text>
            <Text style={{ fontSize: 15, lineHeight: 23, textAlign: "right", color: "#45606D" }}>
              تفاعل WebView والكوكيز وCHAP يحتاج تشغيل التطبيق في Expo Go أو بناء Android. يمكن فتح البوابة خارج المعاينة، لكن ذلك لا يختبر المتصفح الداخلي.
            </Text>
            <Pressable accessibilityRole="link" onPress={openExternal} style={{ alignItems: "center", padding: 15, borderRadius: 15, backgroundColor: "#087E8B" }}>
              <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "700" }}>فتح الرابط في المتصفح الخارجي</Text>
            </Pressable>
          </View>
        ) : (
          <WebView
            key={url}
            source={{ uri: url }}
            originWhitelist={originWhitelist}
            javaScriptEnabled
            domStorageEnabled
            cacheEnabled={false}
            incognito
            sharedCookiesEnabled={false}
            thirdPartyCookiesEnabled={false}
            allowFileAccess={false}
            allowUniversalAccessFromFileURLs={false}
            mixedContentMode="never"
            setSupportMultipleWindows={false}
            injectedJavaScriptForMainFrameOnly
            injectedJavaScript={PAGE_SCAN_SCRIPT}
            onMessage={(event) => {
              const raw = event.nativeEvent.data;
              if (!raw || raw.length > 2048) return;
              try {
                const data: unknown = JSON.parse(raw);
                if (!data || typeof data !== "object") return;
                const value = data as Record<string, unknown>;
                if (value.v !== 1 || value.origin !== origin) return;
                const allowedErrors: PortalErrorCategory[] = ["invalid_credentials", "expired_code", "session_limit", "service_unavailable", "other_error"];
                const fields = Array.isArray(value.fields)
                  ? value.fields.filter((field): field is string => typeof field === "string" && /^[a-z0-9_-]{1,40}$/.test(field)).slice(0, 16)
                  : [];
                onSignal({
                  origin,
                  fields,
                  hasUsernameField: value.hasUsernameField === true,
                  hasPasswordField: value.hasPasswordField === true,
                  hasChapMarkers: value.hasChapMarkers === true,
                  hasLogoutMarker: value.hasLogoutMarker === true,
                  errorCategory: allowedErrors.includes(value.errorCategory as PortalErrorCategory)
                    ? (value.errorCategory as PortalErrorCategory)
                    : null,
                });
              } catch {
                // Ignore malformed messages from page content; never surface their raw text.
              }
            }}
            onShouldStartLoadWithRequest={(request) => {
              const allowed = isAllowedGatewayNavigation(request.url, origin);
              if (!allowed) onBrowserError("حُظر انتقال إلى عنوان خارج بوابة الشبكة. افتح البوابة المطلوبة يدويًا.");
              return allowed;
            }}
            onHttpError={(event) => {
              onBrowserError(`أعادت البوابة استجابة HTTP ${event.nativeEvent.statusCode}.`);
            }}
            onError={() => onBrowserError("تعذر تحميل صفحة البوابة. تحقق من عنوانها وشبكة Wi‑Fi.")}
            onLoadProgress={(event) => {
              if (event.nativeEvent.progress === 1) onBrowserError("");
            }}
            style={{ flex: 1, backgroundColor: "#FFFFFF" }}
          />
        )}
      </View>
    </Modal>
  );
}
