import { classifyPortalErrorText, portalErrorLabel } from "@/features/hotspot/gateway";

export function classifyLoginErrorSnippet(snippet: string): string | null {
  const category = classifyPortalErrorText(snippet);
  return category ? portalErrorLabel(category) : null;
}
