export type GatewayTarget = {
  url: string;
  origin: string;
  hostname: string;
  secure: boolean;
};

export class GatewayAddressError extends Error {
  constructor(message: string, public readonly code: "invalid_address" | "http_confirmation_required") {
    super(message);
    this.name = "GatewayAddressError";
  }
}

export function normalizeGatewayAddress(raw: string, allowInsecureHttp = false): GatewayTarget {
  const trimmed = raw.trim();
  if (!trimmed || trimmed.length > 2048) {
    throw new GatewayAddressError("أدخل عنوان بوابة صحيحًا.", "invalid_address");
  }

  if (/^[a-z][a-z0-9+.-]*:/i.test(trimmed) && !/^https?:\/\//i.test(trimmed)) {
    throw new GatewayAddressError("يسمح فقط بعنوان HTTP أو HTTPS.", "invalid_address");
  }
  const candidate = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new GatewayAddressError("تعذر فهم عنوان البوابة. مثال: a.com أو 192.168.88.1.", "invalid_address");
  }

  if ((parsed.protocol !== "https:" && parsed.protocol !== "http:") || !parsed.hostname || parsed.username || parsed.password) {
    throw new GatewayAddressError("يسمح فقط بعنوان HTTP أو HTTPS دون اسم مستخدم أو كلمة مرور ضمن الرابط.", "invalid_address");
  }
  if (parsed.protocol === "http:" && !allowInsecureHttp) {
    throw new GatewayAddressError("هذه البوابة تستخدم HTTP غير المشفر. أكد ذلك صراحةً قبل المتابعة.", "http_confirmation_required");
  }
  parsed.hash = "";
  return {
    url: parsed.toString(),
    origin: parsed.origin,
    hostname: parsed.hostname.toLowerCase(),
    secure: parsed.protocol === "https:",
  };
}

export function isAllowedGatewayNavigation(candidate: string, expectedOrigin: string): boolean {
  if (candidate === "about:blank") return true;
  try {
    const parsed = new URL(candidate);
    return (parsed.protocol === "https:" || parsed.protocol === "http:") && parsed.origin === expectedOrigin;
  } catch {
    return false;
  }
}

export type PortalErrorCategory =
  | "invalid_credentials"
  | "expired_code"
  | "session_limit"
  | "service_unavailable"
  | "other_error";

export function classifyPortalErrorText(text: string): PortalErrorCategory | null {
  const value = text.trim().toLowerCase().slice(0, 1000);
  if (!value) return null;
  if (/expired|انتهت\s*(الصلاحية|صلاحية)|منتهي\s*الصلاحية/.test(value)) return "expired_code";
  if (/limit|too many|simultaneous|concurrent|الحد\s*الأقصى|عدد\s*الجلسات/.test(value)) return "session_limit";
  if (/radius|server\s*(unavailable|timeout)|service\s*unavailable|خادم\s*غير\s*متاح/.test(value)) return "service_unavailable";
  if (/invalid|incorrect|wrong|unauthori[sz]ed|failed|denied|غير\s*صحيح|مرفوض|خطأ\s*(في\s*)?(كلمة|اسم)/.test(value)) {
    return "invalid_credentials";
  }
  return "other_error";
}

export function portalErrorLabel(category: PortalErrorCategory): string {
  const labels: Record<PortalErrorCategory, string> = {
    invalid_credentials: "رفضت الصفحة بيانات الدخول أو صيغة البطاقة.",
    expired_code: "تشير الصفحة إلى انتهاء صلاحية البطاقة أو الرمز.",
    session_limit: "تشير الصفحة إلى بلوغ حد الجلسات.",
    service_unavailable: "تشير الصفحة إلى تعذر خدمة المصادقة أو الخادم.",
    other_error: "أبلغت صفحة البوابة عن خطأ؛ راجع تفاصيلها داخل المتصفح.",
  };
  return labels[category];
}
