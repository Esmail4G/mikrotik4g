export type LengthHoldout = {
  tested: number;
  correct: number;
  accuracyPercent: number;
};

export type CardPatternReport = {
  prefix: string;
  inputCells: number;
  uniqueValidCards: number;
  duplicateCards: number;
  ignoredCells: number;
  matchingCards: number;
  lengths: Array<{ length: number; count: number }>;
  theoreticalByLength: Array<{ length: number; possibilities: string }>;
  theoreticalPossibilities: string;
  observedPrefixCounts: Array<{ prefix: string; count: number }>;
  digitFrequencyByPosition: Array<{ position: number; counts: Array<{ digit: string; count: number }> }>;
  consecutiveRuns: Array<{ length: number; first: string; last: string }>;
  lengthHoldout: LengthHoldout | null;
  caveat: string;
};

export type ParsedSample = {
  cards: string[];
  inputCells: number;
  ignoredCells: number;
};

const MIN_CARD_LENGTH = 3;
const MAX_CARD_LENGTH = 32;
const MIN_HOLDOUT_SAMPLE = 10;
const FOLDS = 5;

export function normalizeDigits(value: string): string {
  return value.replace(/[٠-٩۰-۹]/g, (digit) => {
    const code = digit.charCodeAt(0);
    const base = code >= 0x06f0 ? 0x06f0 : 0x0660;
    return String(code - base);
  });
}

export function parseCardSampleText(text: string): ParsedSample {
  const normalized = normalizeDigits(text.replace(/^\uFEFF/, ""));
  const cells = normalized.split(/[\r\n,;\t|]+/).map((cell) => cell.trim().replace(/^['"]|['"]$/g, ""));
  const nonEmpty = cells.filter(Boolean);
  const cards: string[] = [];
  let ignoredCells = 0;

  for (const cell of nonEmpty) {
    if (/^\d+$/.test(cell) && cell.length >= MIN_CARD_LENGTH && cell.length <= MAX_CARD_LENGTH) {
      cards.push(cell);
    } else {
      ignoredCells += 1;
    }
  }

  const unique = [...new Set(cards)].sort(compareCardNumbers);
  return {
    cards: unique,
    inputCells: nonEmpty.length,
    ignoredCells,
  };
}

export function analyzeCardSample(text: string, prefixInput: string): CardPatternReport {
  const prefix = normalizeDigits(prefixInput.trim());
  if (!/^\d{2}$/.test(prefix)) {
    throw new Error("أدخل بادئة من رقمين بالضبط.");
  }

  const parsed = parseCardSampleText(text);
  const matching = parsed.cards.filter((card) => card.startsWith(prefix));
  const lengths = countBy(matching.map((card) => card.length));
  const theoreticalByLength = [...lengths.entries()]
    .sort(([a], [b]) => a - b)
    .map(([length]) => ({ length, possibilities: powerOfTen(length - 2) }));
  const theoreticalPossibilities = theoreticalByLength.reduce(
    (sum, item) => addDecimalStrings(sum, item.possibilities),
    "0",
  );

  const prefixCounts = countBy(parsed.cards.map((card) => card.slice(0, 2)));
  const maxPosition = matching.reduce((max, card) => Math.max(max, card.length), 0);
  const digitFrequencyByPosition = Array.from({ length: maxPosition }, (_, position) => {
    const counts = new Map<string, number>();
    for (const card of matching) {
      const digit = card[position];
      if (digit !== undefined) counts.set(digit, (counts.get(digit) ?? 0) + 1);
    }
    return {
      position: position + 1,
      counts: [...counts.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([digit, count]) => ({ digit, count })),
    };
  }).filter((item) => item.counts.length > 0);

  return {
    prefix,
    inputCells: parsed.inputCells,
    uniqueValidCards: parsed.cards.length,
    duplicateCards: Math.max(0, parsed.inputCells - parsed.ignoredCells - parsed.cards.length),
    ignoredCells: parsed.ignoredCells,
    matchingCards: matching.length,
    lengths: [...lengths.entries()].sort(([a], [b]) => a - b).map(([length, count]) => ({ length, count })),
    theoreticalByLength,
    theoreticalPossibilities,
    observedPrefixCounts: [...prefixCounts.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([value, count]) => ({ prefix: value, count })),
    digitFrequencyByPosition,
    consecutiveRuns: findConsecutiveRuns(matching),
    lengthHoldout: matching.length >= MIN_HOLDOUT_SAMPLE ? crossValidateLength(matching) : null,
    caveat:
      "النتائج وصفية للعينة فقط. دقة الاختبار تخص طول البطاقة وحده ولا تتنبأ بالأرقام اللاحقة أو بإمكانية تسجيل الدخول.",
  };
}

function countBy<T extends string | number>(values: T[]): Map<T, number> {
  const counts = new Map<T, number>();
  for (const value of values) counts.set(value, (counts.get(value) ?? 0) + 1);
  return counts;
}

function compareCardNumbers(a: string, b: string): number {
  return a.length - b.length || a.localeCompare(b);
}

function powerOfTen(exponent: number): string {
  return `1${"0".repeat(Math.max(0, exponent))}`;
}

function addDecimalStrings(left: string, right: string): string {
  let carry = 0;
  let result = "";
  const width = Math.max(left.length, right.length);
  for (let offset = 0; offset < width; offset += 1) {
    const a = Number(left[left.length - 1 - offset] ?? 0);
    const b = Number(right[right.length - 1 - offset] ?? 0);
    const sum = a + b + carry;
    result = String(sum % 10) + result;
    carry = Math.floor(sum / 10);
  }
  return (carry ? String(carry) : "") + result;
}

function crossValidateLength(cards: string[]): LengthHoldout {
  let tested = 0;
  let correct = 0;
  for (let fold = 0; fold < FOLDS; fold += 1) {
    const training = cards.filter((_, index) => index % FOLDS !== fold);
    const holdout = cards.filter((_, index) => index % FOLDS === fold);
    if (training.length === 0 || holdout.length === 0) continue;
    const distribution = countBy(training.map((card) => card.length));
    const predictedLength = [...distribution.entries()].sort(
      ([lengthA, countA], [lengthB, countB]) => countB - countA || lengthA - lengthB,
    )[0]?.[0];
    if (predictedLength === undefined) continue;
    for (const card of holdout) {
      tested += 1;
      if (card.length === predictedLength) correct += 1;
    }
  }
  return {
    tested,
    correct,
    accuracyPercent: tested ? Math.round((correct / tested) * 100) : 0,
  };
}

function incrementDecimal(value: string): string {
  const digits = value.split("");
  for (let index = digits.length - 1; index >= 0; index -= 1) {
    if (digits[index] !== "9") {
      digits[index] = String(Number(digits[index]) + 1);
      return digits.join("");
    }
    digits[index] = "0";
  }
  return `1${digits.join("")}`;
}

function findConsecutiveRuns(cards: string[]): Array<{ length: number; first: string; last: string }> {
  const sorted = [...cards].sort(compareCardNumbers);
  const runs: Array<{ length: number; first: string; last: string }> = [];
  let start: string | undefined;
  let previous: string | undefined;
  let runLength = 0;

  const saveRun = () => {
    if (start && previous && runLength >= 2) runs.push({ length: runLength, first: start, last: previous });
  };

  for (const card of sorted) {
    if (previous && card.length === previous.length && card === incrementDecimal(previous)) {
      runLength += 1;
      previous = card;
      continue;
    }
    saveRun();
    start = card;
    previous = card;
    runLength = 1;
  }
  saveRun();
  return runs;
}
