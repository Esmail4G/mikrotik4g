from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets" / "images"
ASSETS.mkdir(parents=True, exist_ok=True)
SCALE = 3
SIZE = 1024
NAVY = (7, 23, 34, 255)
TEAL = (76, 201, 192, 255)
WHITE = (245, 251, 253, 255)


def draw_mark(color=TEAL, secondary=WHITE):
    canvas = Image.new("RGBA", (SIZE * SCALE, SIZE * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    scale = lambda values: tuple(int(value * SCALE) for value in values)

    shield = [(512, 118), (812, 238), (808, 492), (747, 680), (512, 881), (277, 680), (216, 492), (212, 238)]
    draw.line([scale(point) for point in shield + [shield[0]]], fill=color, width=34 * SCALE, joint="curve")

    center_y = 658
    for radius, width in ((205, 38), (143, 34), (83, 31)):
        box = (512 - radius, center_y - radius, 512 + radius, center_y + radius)
        draw.arc(scale(box), start=218, end=322, fill=secondary, width=width * SCALE)
    draw.ellipse(scale((475, 714, 549, 788)), fill=secondary)
    return canvas.resize((SIZE, SIZE), Image.Resampling.LANCZOS)


def write_png(name, image):
    image.save(ASSETS / name, format="PNG", optimize=True)


mark = draw_mark()
mono = draw_mark((255, 255, 255, 255), (255, 255, 255, 255))
full = Image.new("RGBA", (SIZE, SIZE), NAVY)
full.alpha_composite(mark)
write_png("icon.png", full)
write_png("splash-icon.png", mark)
write_png("android-icon-foreground.png", mark)
write_png("android-icon-monochrome.png", mono)
write_png("android-icon-background.png", Image.new("RGBA", (SIZE, SIZE), NAVY))
write_png("favicon.png", full.resize((96, 96), Image.Resampling.LANCZOS))

print("Generated branding assets:")
for name in (
    "icon.png",
    "splash-icon.png",
    "favicon.png",
    "android-icon-foreground.png",
    "android-icon-background.png",
    "android-icon-monochrome.png",
):
    path = ASSETS / name
    print(f"- {path} ({path.stat().st_size} bytes)")
