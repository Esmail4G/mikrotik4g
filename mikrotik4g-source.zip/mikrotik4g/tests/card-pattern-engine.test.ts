import { describe, expect, it } from "vitest";
import { analyzeCardSample, normalizeDigits, parseCardSampleText } from "../features/patterns/card-pattern-engine";

const synthetic = Array.from({ length: 15 }, (_, index) => `4242000${String(index + 1).padStart(3, "0")}`).join("\n");

describe("CardPatternEngine", () => {
  it("normalizes Arabic-Indic digits and imports TXT/CSV cells without inventing data", () => {
    expect(normalizeDigits("٤٢ ۰۱۲")).toBe("42 012");
    const parsed = parseCardSampleText('code,serial\n"421234", 421235\n421234\ntext');
    expect(parsed.cards).toEqual(["421234", "421235"]);
    expect(parsed.ignoredCells).toBe(3);
    expect(parsed.inputCells).toBe(6);
  });

  it("reports theory and observed support separately and detects consecutive runs", () => {
    const result = analyzeCardSample(synthetic, "42");
    expect(result.matchingCards).toBe(15);
    expect(result.theoreticalPossibilities).toBe("100000000");
    expect(result.lengths).toEqual([{ length: 10, count: 15 }]);
    expect(result.consecutiveRuns).toEqual([{ length: 15, first: "4242000001", last: "4242000015" }]);
    expect(result.lengthHoldout).toEqual({ tested: 15, correct: 15, accuracyPercent: 100 });
    expect(result.caveat).toContain("لا تتنبأ");
  });

  it("does not report a confidence percentage for a small sample", () => {
    const result = analyzeCardSample("42123\n42124\n42125", "42");
    expect(result.matchingCards).toBe(3);
    expect(result.lengthHoldout).toBeNull();
  });

  it("calculates positional frequencies only for cards matching the selected prefix", () => {
    const result = analyzeCardSample("421234\n423456\n991234", "42");
    expect(result.digitFrequencyByPosition[0].counts).toEqual([{ digit: "4", count: 2 }]);
    expect(result.digitFrequencyByPosition[1].counts).toEqual([{ digit: "2", count: 2 }]);
  });

  it("requires exactly two numeric prefix characters", () => {
    expect(() => analyzeCardSample(synthetic, "4")).toThrow("رقمين");
    expect(() => analyzeCardSample(synthetic, "4x")).toThrow("رقمين");
  });
});
