import { describe, expect, it } from "vitest";
import { computeChapResponse, md5HexUtf8, parseChapIdentifier, parseHexBytes } from "../features/chap/chap";

describe("MikroTik CHAP helper", () => {
  it("matches a published MD5 digest vector", () => {
    expect(md5HexUtf8("abc")).toBe("900150983cd24fb0d6963f7d28e17f72");
  });

  it("hashes identifier byte, UTF-8 secret and challenge bytes in protocol order", () => {
    expect(computeChapResponse({ chapId: "0x01", password: "hello", challengeHex: "0123456789abcdef" }))
      .toBe("e0ac23de3238495e1ac9beb949a94416");
    expect(computeChapResponse({ chapId: 7, password: "كلمة مرور", challengeHex: "00112233445566778899aabbccddeeff" }))
      .toBe("d700c6377deff762ad22b72ef212e7bb");
  });

  it("accepts decimal and explicit hexadecimal chap-id forms", () => {
    expect(parseChapIdentifier("10")).toBe(10);
    expect(parseChapIdentifier("0x0a")).toBe(10);
    expect(parseChapIdentifier("0A")).toBe(10);
  });

  it("rejects malformed identifiers and challenges instead of silently hashing them", () => {
    expect(() => parseChapIdentifier(256)).toThrow("بايتًا");
    expect(() => parseHexBytes("123")).toThrow("سداسية عشرية");
    expect(() => computeChapResponse({ chapId: 1, password: "x", challengeHex: "zz" })).toThrow("سداسية عشرية");
  });
});
