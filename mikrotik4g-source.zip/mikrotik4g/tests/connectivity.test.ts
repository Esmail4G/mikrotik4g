import { describe, expect, it, vi } from "vitest";
import { CONNECTIVITY_CHECK_URL, probeInternet, type ProbeDependencies } from "../features/connectivity/internet-probe";

function makeDeps(type: string, connected = true, status = 204): ProbeDependencies & { fetcher: ReturnType<typeof vi.fn> } {
  return {
    getNetworkState: async () => ({ type: type as never, isConnected: connected }),
    fetcher: vi.fn(async () => ({ status })),
    timeoutMs: 20,
  };
}

describe("internet reachability probe", () => {
  it("does not start a probe on cellular and never reports success", async () => {
    const dependencies = makeDeps("CELLULAR");
    const result = await probeInternet(dependencies);
    expect(result.status).toBe("wifi_required");
    expect(dependencies.fetcher).not.toHaveBeenCalled();
  });

  it("refuses a VPN-only reported route", async () => {
    const result = await probeInternet(makeDeps("VPN"));
    expect(result.status).toBe("wifi_required");
  });

  it("reports actual 204 reachability but marks Wi-Fi binding unverified", async () => {
    const dependencies = makeDeps("WIFI");
    const result = await probeInternet(dependencies);
    expect(result.status).toBe("system_route_reachable");
    expect(result.wifiBindingVerified).toBe(false);
    expect(dependencies.fetcher).toHaveBeenCalledWith(CONNECTIVITY_CHECK_URL, expect.objectContaining({ method: "GET" }));
  });

  it("does not treat a captive-portal 200 page as verified external access", async () => {
    const result = await probeInternet(makeDeps("WIFI", true, 200));
    expect(result.status).toBe("no_external_access");
  });

  it("does not claim internet when the system reports no active Wi-Fi", async () => {
    const result = await probeInternet(makeDeps("WIFI", false));
    expect(result.status).toBe("no_connection");
  });
});
