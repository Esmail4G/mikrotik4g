import { describe, expect, it } from "vitest";
import {
  classifyPortalErrorText,
  isAllowedGatewayNavigation,
  normalizeGatewayAddress,
} from "../features/hotspot/gateway";

describe("MikroTik gateway helpers", () => {
  it("defaults a bare hostname to HTTPS", () => {
    expect(normalizeGatewayAddress(" a.com ").url).toBe("https://a.com/");
    expect(normalizeGatewayAddress("https://router.example/login").origin).toBe("https://router.example");
  });

  it("requires an explicit caller choice before opening HTTP", () => {
    expect(() => normalizeGatewayAddress("http://192.168.88.1")).toThrow("HTTP غير المشفر");
    expect(normalizeGatewayAddress("http://192.168.88.1", true).secure).toBe(false);
  });

  it("rejects credential-bearing and non-web URLs", () => {
    expect(() => normalizeGatewayAddress("https://user:pass@router.local")).toThrow("دون اسم مستخدم");
    expect(() => normalizeGatewayAddress("javascript:alert(1)")).toThrow("HTTP أو HTTPS");
  });

  it("restricts navigation to the selected origin", () => {
    expect(isAllowedGatewayNavigation("https://router.local/login", "https://router.local")).toBe(true);
    expect(isAllowedGatewayNavigation("https://other.example/", "https://router.local")).toBe(false);
    expect(isAllowedGatewayNavigation("file:///etc/passwd", "https://router.local")).toBe(false);
  });

  it("maps common login failures to a safe category without returning raw page text", () => {
    expect(classifyPortalErrorText("Invalid username or password")).toBe("invalid_credentials");
    expect(classifyPortalErrorText("Voucher expired")).toBe("expired_code");
    expect(classifyPortalErrorText("Too many simultaneous sessions")).toBe("session_limit");
    expect(classifyPortalErrorText("")).toBeNull();
  });
});
